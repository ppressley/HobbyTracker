//
//  ContentView.swift
//  HobbyTracker
//
//  Created by Student on 10/2/23.
//

import SwiftUI

struct ContentView: View {
    @State private var hobbies = ["Reading 📗", "Cooking 🍳", "Fishing 🎣", "Boxing 🥊", "Gardening 🪴", "Swimming 🏊‍♂️", "Biking 🚴‍♀️", "Dancing 🕺", "Running 🏃‍♀️", "Fitness 🏋️"]
    @State private var testHobbies: [String] = []
    @State private var showAlert = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    var body: some View {
        
        NavigationView {
            ZStack {
                LinearGradient(
                    colors: [.orange, .red],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                    )
                .ignoresSafeArea()
                
                VStack {
                    Spacer()
                    if hobbies.isEmpty { //Change hobbies on this line to testHobbies for non-preloaded hobby contentview
                                    Text("No Hobbies Yet!")
                                        .foregroundColor(.red)
                                        .font(.headline)
                    } else {
                            List(hobbies, id: \.self) {
                                    Text($0)
                                    .listRowBackground(Color.orange)
                        }
                        .scrollContentBackground(.hidden)
                    }
                    HStack {
                        Text("**Add Hobby**")
                            .font(.system(size: 30))
                        NavigationLink(destination: View1(hobbies: $hobbies, showAlert: $showAlert, alertTitle: $alertTitle, alertMessage: $alertMessage)) {
                            Text("**+**")
                                .foregroundColor(Color.orange)
                                .font(.system(size: 50))
                                
                                .navigationTitle("Hobby Tracker")
                        }
                    }
                    Spacer()
                }
            }
        }
    }
}


private extension ContentView {
    struct View1: View {
        @Binding var hobbies: [String]
        let pickerHobbies = ["", "🧗‍♂️", "🥾", "🛌", "🎤", "📙", "✍️", "🖍️", "🧶", "🧹", "🏎️", "✈️", "🎭", "🛵", "🏈", "🛒", "🛠️", "🛼", "🤿", "🛹"]
        @Binding var showAlert: Bool
        @Binding var alertTitle: String
        @Binding var alertMessage: String
        @State private var newhobby: String = ""
        @State private var newEmoji: String = ""
        @State private var pickerSelection = ""
        var body: some View {
            ZStack {
                LinearGradient(
                    colors: [.red, .yellow],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                    )
                .ignoresSafeArea()
                VStack {
                    Text("**New Hobby**")
                        .font(.system(size: 50))
                    Spacer()
                    Spacer()
                    Spacer()
                    
                    Form {
                        TextField("Add Hobby",text: $newhobby)
                        Picker(selection: $pickerSelection,
                               label: Text(""), content: {
                            ForEach(pickerHobbies, id: \.self)  { emoji in
                                           Text(emoji).tag(emoji)
                                        .font(.system(size: 25))
                            }
                        })
                        .pickerStyle(WheelPickerStyle())
                        .onChange(of: pickerSelection, perform: { emoji in
                                        newEmoji = emoji
                                    })
                    }
                    .frame(width: 350, height: 400)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(.orange, lineWidth: 10)
                    )
                    Spacer()
                    Button("**Submit**") {
                        if !hobbyCheckDuplicate(submittedHobby: newhobby, hobbies: hobbies) {
                            showAlertF(title: "This Hobby already exists.", message: "There can be no duplicates")
                                } else if !hobbyCheckSize(submittedHobby: newhobby, hobbies: hobbies) {
                                    showAlertF(title: "This Hobby isn't the right size.", message: "Hobbies are anywhere from 3 to 16 characters.")
                                } else {
                                    newhobby = newhobby + " " + newEmoji
                                    hobbies.append(newhobby)
                                    presentationMode.wrappedValue.dismiss()
                                }
                    }
                    .font(.system(size: 20))
                    .alert(isPresented: $showAlert) {
                        Alert(
                            title: Text(alertTitle),
                            message: Text(alertMessage),
                            dismissButton: .default(Text("OK"))
                        )
                    }
                    .font(.headline)
                                        .foregroundColor(.orange)
                                        .padding()
                                        .frame(maxWidth: .infinity)
                                        .background(Color.yellow)
                                        .cornerRadius(10)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 10)
                                                .stroke(Color.orange, lineWidth: 4)
                                        )
                                        .padding(.horizontal, 100)
                    Spacer()
                    Spacer()
                }
            }
        }
        func showAlertF(title: String, message: String) {
            alertTitle = title
            alertMessage = message
            showAlert = true
        }
        @Environment(\.presentationMode) var presentationMode
    }
}

func hobbyCheckDuplicate(submittedHobby: String, hobbies: Array<String>) -> Bool {
    let processedHobby = submittedHobby.lowercased()
    for hobby in hobbies {
        let tmpHobby = hobby.dropLast().dropLast()
        if(processedHobby == tmpHobby.lowercased()) {
            return false
        }
    }
    return true
}

func hobbyCheckSize(submittedHobby: String, hobbies: Array<String>) -> Bool {
    if (submittedHobby.count < 3 || submittedHobby.count > 16) {
        return false
    }
    else {
        return true
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

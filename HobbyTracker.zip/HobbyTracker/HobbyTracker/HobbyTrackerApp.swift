//
//  HobbyTrackerApp.swift
//  HobbyTracker
//
//  Created by Student on 10/2/23.
//

import SwiftUI

@main
struct HobbyTrackerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

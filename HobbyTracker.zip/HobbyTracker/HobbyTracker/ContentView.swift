//
//  ContentView.swift
//  HobbyTracker
//
//  Created by Student on 10/2/23.
//

import SwiftUI

struct ContentView: View {
    @State private var hobbies = ["Reading 📗", "Cooking 🍳", "Fishing 🎣", "Boxing 🥊", "Gardening 🪴", "Swimming 🏊‍♂️", "Biking 🚴‍♀️", "Dancing 🕺", "Running 🏃‍♀️", "Fitness 🏋️"]
    var body: some View {
        
        NavigationView {
            ZStack {
                LinearGradient(
                    colors: [.orange, .red],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                    )
                .ignoresSafeArea()
                
                VStack {
                    Spacer()
                        List(hobbies, id: \.self) {
                            Text($0)
                         }
                    
                    .frame(width: 350, height: 500)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(.orange, lineWidth: 10)
                    )
                    HStack {
                        Text("Add Hobby")
                            .font(.system(size: 30))
                        NavigationLink(destination: View1(hobbies: $hobbies)) {
                            Text("+")
                                .font(.system(size: 50))
                                .navigationTitle("Hobby Tracker")
                        }
                    }
                    Spacer()
                }
            }
        }
    }
}


private extension ContentView {
    struct View1: View {
        @Binding var hobbies: [String]
        let pickerHobbies = ["", "🧗‍♂️", "🥾", "🛌", "🎤", "📙", "✍️", "🖍️", "🧶", "🧹", "🏎️", "✈️", "🎭", "🛵", "🏈", "🛒", "🛠️", "🛼", "🤿", "🛹"]
        @State private var showAlert = false
        @State private var newhobby: String = ""
        @State private var newEmoji: String = ""
        @State private var pickerSelection = ""
        @State private var showingAlertDuplicate = false
        @State private var showingAlertSize = false
        var body: some View {
            ZStack {
                LinearGradient(
                    colors: [.red, .yellow],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                    )
                .ignoresSafeArea()
                VStack {
                    Text("New Hobby")
                        .font(.system(size: 50))
                    Spacer()
                    Spacer()
                    Spacer()
                    
                    Form {
                        TextField("Add Hobby",text: $newhobby)
                        Picker(selection: $pickerSelection,
                               label: Text(""), content: {
                            ForEach(pickerHobbies, id: \.self)  { emoji in
                                           Text(emoji).tag(emoji)
                            }
                        })
                        .pickerStyle(WheelPickerStyle())
                        .onChange(of: pickerSelection, perform: { emoji in
                                        newEmoji = emoji
                                    })
                    }
                    .frame(width: 350, height: 400)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(.orange, lineWidth: 10)
                    )
                    Button("Submit") {
                        if !hobbyCheckDuplicate(submittedHobby: newhobby, hobbies: hobbies) {
                            showingAlertDuplicate = true
                        } else if !hobbyCheckSize(submittedHobby: newhobby, hobbies: hobbies) {
                            showingAlertSize = true
                        } else {
                            newhobby = newhobby + " " + newEmoji
                            hobbies.append(newhobby)
                        }
                    }
                    .font(.system(size: 20))
                    .alert(isPresented: $showingAlertSize) {
                        Alert(
                            title: Text("This Hobby isn't the right size."),
                            message: Text("Hobbies are anywhere from 3 to 16 characters."),
                            dismissButton: .default(Text("OK"))
                        )
                    }
                    .alert(isPresented: $showingAlertDuplicate) {
                        Alert(
                            title: Text("This Hobby already exists."),
                            message: Text("There can be no duplicates"),
                            dismissButton: .default(Text("OK"))
                        )
                    }
                    Spacer()
                    Spacer()
                }
            }
        }
    }
}

func hobbyCheckDuplicate(submittedHobby: String, hobbies: Array<String>) -> Bool {
    let processedHobby = submittedHobby.lowercased()
    for hobby in hobbies {
        let tmpHobby = hobby.dropLast().dropLast()
        if(processedHobby == tmpHobby.lowercased()) {
            return false
        }
    }
    return true
}

func hobbyCheckSize(submittedHobby: String, hobbies: Array<String>) -> Bool {
    if (submittedHobby.count < 3 || submittedHobby.count > 16) {
        return false
    }
    else {
        return true
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

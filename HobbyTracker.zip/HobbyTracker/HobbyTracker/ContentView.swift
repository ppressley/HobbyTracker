//
//  ContentView.swift
//  HobbyTracker
//
//  Created by Student on 10/2/23.
//

import SwiftUI

struct ContentView: View {
    @State private var hobbies = ["Reading 📗", "Cooking 🍳", "Fishing 🎣", "Boxing 🥊", "Gardening 🪴", "Swimming 🏊‍♂️", "Biking 🚴‍♀️", "Dancing 🕺", "Running 🏃‍♀️", "Fitness 🏋️"]
    var body: some View {
        
        NavigationView {
            ZStack {
                LinearGradient(
                    colors: [.orange, .red],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                    )
                .ignoresSafeArea()
                
                VStack {
                    Spacer()
                        List(hobbies, id: \.self) {
                            Text($0)
                         }
                    
                    .frame(width: 350, height: 500)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(.orange, lineWidth: 10)
                    )
                    HStack {
                        Text("Add Hobby")
                            .font(.system(size: 30))
                        NavigationLink(destination: View1(hobbies: $hobbies)) {
                            Text("+")
                                .font(.system(size: 50))
                                .navigationTitle("Hobby Tracker")
                        }
                    }
                    Spacer()
                }
            }
        }
    }
}


private extension ContentView {
    struct View1: View {
        @Binding var hobbies: [String]
        let pickerHobbies = ["", "🧗‍♂️", "🥾", "🛌", "🎤", "📙", "✍️", "🖍️", "🧶", "🧹", "🏎️", "✈️", "🎭", "🛵", "🏈", "🛒", "🛠️", "🛼", "🤿", "🛹"]
        @State private var showAlert = false
        @State private var newhobby: String = ""
        @State private var pickerSelection = 0
        @State private var selectedHobby = ""
        var body: some View {
            ZStack {
                LinearGradient(
                    colors: [.red, .yellow],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                    )
                .ignoresSafeArea()
                VStack {
                    Text("New Hobby")
                        .font(.system(size: 50))
                    Spacer()
                    Spacer()
                    Spacer()
                    Form {
                        Picker(selection: $pickerSelection,
                               label: TextField("Add Hobby",text: $newhobby), content: {
                            ForEach(pickerHobbies, id: \.self)  { emoji in
                                           Text(emoji).tag(emoji)
                            }
                        })
                        .pickerStyle(.menu)
                        Button("Submit") {
                            hobbies.append("New Hobby")
                            Alert(title: Text("Hobby Submitted"))
                        }
                        
                    }
                    .frame(width: 350, height: 400)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(.orange, lineWidth: 10)
                    )
                    Spacer()
                    Spacer()
                }
            }
        }
    }
}

func hobbyNew(submittedHobby: String) -> Void {
    let submittedHobby = "test"
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

//
//  ContentView.swift
//  HobbyTracker
//
//  Created by Student on 10/2/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Hobby")
                .lineLimit(1)
                .bold()
            Spacer()
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

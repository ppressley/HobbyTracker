//
//  ContentView.swift
//  HobbyTracker
//
//  Created by Student on 10/2/23.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        
        NavigationView {
            ZStack {
                LinearGradient(
                    colors: [.orange, .red],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                    )
                .ignoresSafeArea()
                
                VStack {
                    Spacer()
                    List {
                        Text("Reading")
                        Text("Cooking")
                        Text("Fishing")
                        Text("Boxing")
                        Text("Gardening")
                        Text("Swimming")
                        Text("Biking")
                        Text("Dancing")
                        Text("Running")
                        Text("Fitness")
                    }
                    .frame(width: 350, height: 500)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(.orange, lineWidth: 10)
                    )
                    HStack {
                        Text("Add Hobby")
                            .font(.system(size: 30))
                        NavigationLink(destination: View1()) {
                            Text("+")
                                .font(.system(size: 50))
                                .navigationTitle("Hobby Tracker")
                        }
                    }
                    Spacer()
                }
            }
        }
    }
}


private extension ContentView {
    struct View1: View {
        @State private var newhobby: String = ""
        @State private var pickerSelection = 0
        var body: some View {
            ZStack {
                LinearGradient(
                    colors: [.red, .yellow],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                    )
                .ignoresSafeArea()
                VStack {
                    Text("New Hobby")
                        .font(.system(size: 50))
                    Spacer()
                    Spacer()
                    Spacer()
                    Form {
                        Picker(selection: $pickerSelection,
                               label: TextField("Add Hobby",text: $newhobby), content: {
                                Text("Sample Value 1").tag(0)
                                Text("Sample Value 2").tag(1)
                                Text("Sample Value 3").tag(2) })
                        
                    }
                    .frame(width: 350, height: 500)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(.orange, lineWidth: 10)
                    )
                    Spacer()
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
